package mx.tecnm.orizaba.tp.gimnasio.eventos;

/** Clasificación de los eventos publicados por el servicio. */
public enum TipoEvento {
    ALTA, CAMBIO_ESTADO, ALERTA, CANCELACION_AUTOMATICA
}
